
  # Financial Literacy Game Website

  This is a code bundle for Financial Literacy Game Website. The original project is available at https://www.figma.com/design/Mog3NFdaVF073zabf5QMGv/Financial-Literacy-Game-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  